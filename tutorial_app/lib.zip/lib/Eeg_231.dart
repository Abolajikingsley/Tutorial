import 'package:flutter/material.dart';


class MyHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Eeg_231'),
      ),
      body: Column(children: [
        Container(width: double.infinity,),
        const Card(child: Text('topic 1'),),
        const Card(child: Text('topic 2'),),
        const Card(child: Text('topic 3'),),
        const Card(child: Text('topic 4'),),
        const Card(child: Text('topic 5'),),
        const Card(child: Text('topic 6'),),
        const Card(child: Text('topic 7'),),
        const Card(child: Text('topic 8'),),
        const Card(child: Text('topic 9'),),
        const Card(child: Text('topic 10'),),
        const Card(child: Text('an Osobamiro Abolaji Prouction'),), 
        const Card(child: Text('@ 2022'),)     

      ],)
    );
  }
}
