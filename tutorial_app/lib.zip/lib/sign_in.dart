// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';


class MyHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('X App Sign in', textAlign: TextAlign.center),),
      body: Card(child: Container(child: Column(children: const [
        Text('Create your profile'),
        TextField(decoration: InputDecoration(labelText: 'Preferred Name'),),
        TextField(decoration: InputDecoration(labelText: 'Department'),),
        TextField(decoration: InputDecoration(labelText: 'Matric Number'),),
        TextField(decoration: InputDecoration(labelText: 'Present Year'),),
        TextField(decoration: InputDecoration(labelText: 'other interests'),),
        ElevatedButton(onPressed: onPressed, child: Text('Create my profile'),)
        ],
      ),),)
      ),