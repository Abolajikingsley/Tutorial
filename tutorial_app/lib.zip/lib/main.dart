import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter App',
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Geg_217'),
      ),
      body: Column(children: [
        Container(width: double.infinity,),
        Card(child: Text('topic 1'),),
        Card(child: Text('topic 2'),),

      ],)
    );
  }
}
