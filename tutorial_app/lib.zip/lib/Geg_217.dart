import 'package:flutter/material.dart';


class MyHomePage extends StatelessWidget {
  const MyHomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Eeg_211'),
      ),
      body: Column( mainAxisAlignment: MainAxisAlignment.start, crossAxisAlignment: CrossAxisAlignment.center, children: [
        Container(margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 15,),
        decoration: BoxDecoration(border: Border.all(color: Colors.indigoAccent, width: 2,)),
        padding: const EdgeInsets.all(10),
        ),
        const Card(child: Text('topic 1', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 120, color: Colors.indigoAccent,),),),
        const Card(child: Text('topic 2', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 120, color: Colors.indigoAccent,),),),
        const Card(child: Text('topic 3', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 120, color: Colors.indigoAccent,),),),
        const Card(child: Text('topic 4', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 120, color: Colors.indigoAccent,),),),
        const Card(child: Text('topic 5', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 120, color: Colors.indigoAccent,),),),
        const Card(child: Text('topic 6', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 120, color: Colors.indigoAccent,),),),
        const Card(child: Text('topic 7', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 120, color: Colors.indigoAccent,),),),
        const Card(child: Text('topic 8', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 120, color: Colors.indigoAccent,),),),
        const Card(child: Text('topic 9', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 120, color: Colors.indigoAccent,),),),
        const Card(child: Text('topic 10', textAlign: TextAlign.center,style: TextStyle(fontWeight: FontWeight.bold, fontSize: 120, color: Colors.indigoAccent,),),),
        const Card(child: Text('an Osobamiro Abolaji Production', textAlign: TextAlign.center,),), 
        const Card(child: Text('@ 2022', textAlign: TextAlign.center,),)     

      ],)
    );
  }
}
